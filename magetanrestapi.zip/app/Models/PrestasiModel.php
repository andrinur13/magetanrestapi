<?php

namespace App\Models;

use CodeIgniter\Model;

class PrestasiModel extends Model
{

    protected $table = 'prestasi';
    protected $useTimestamps = true;
    protected $primaryKey = 'id_prestasi';
    protected $allowedFields = ['id_data_siswa', 'tingkat', 'penyelenggara', 'nama_kegiatan', 'hasil', 'tgl_kegiatan', 'foto_kegiatan', 'piagam'];
    protected $useSoftDeletes = true;

    

    public function getPrestasi($id = false)
    {

        if ($id == false) {
            // jika id tidak ada
            // maka kembalikan semua data prestasi
            return $this->findAll();
        } else {
            // id ada
            return $this->find($id);
        }
    }


    public function getPrestasiDataSiswa($id = false)
    {

        $db = \Config\Database::connect();
        $builder = $db->table('prestasi');

        if (!$id) {
            return null;
        } else {
            return $builder->getWhere(['id_data_siswa' => $id])->getResultArray();
        }
    }


    public function storePrestasi($data)
    {
        return $this->insert($data);
    }


    public function updatePrestasi($data, $id) {
        $this->update($id, $data);
    }


    public function deletePrestasi($id) {
        $this->delete($id);
    }
}
